<?php
$nome = $_GET['nome'];
$area = $_GET['area'];
$carga = $_GET['carga'];

// INSERT INTO curso (nome, area, carga_horaria)
// VALUES ("Tec. em Agropecuária", "Agrárias", 3200);
$sql = "INSERT INTO curso (nome, area, carga_horaria) VALUES ('$nome', '$area', $carga);";

require_once "conexao.php";
mysqli_query($conexao, $sql);

header("Location: cad_curso.php");
?>