<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h3>Cadastro de Curso</h3>
    <!-- action: para quem estou mandando os dados -->
    <!-- method: como estou mandando os dados -->
    <form action="salvar_curso.php" method="GET">
        Nome: <br>
        <input type="text" name="nome"> <br>
        
        Área: <br>
        <input type="text" name="area"> <br>
        
        Carga horária: <br>
        <input type="text" name="carga"> <br>
        
        <input type="submit" value="Cadastrar">
    </form>
</body>
</html>